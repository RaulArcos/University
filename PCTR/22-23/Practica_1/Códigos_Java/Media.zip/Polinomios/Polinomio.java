  package Polinomios;

//  import Polinomios.*;

  public class Polinomio {
    //Uso de clase amiga
    private Monomio mon;
    public Polinomio() {new Monomio();}
  }
