/**
 * Programa en Java que escribe "Hola mundo." en la pantalla.
 *
 * @author Natalia Partera
 * @version 1.0
 */
public class Hola_mundo
{
  public static void main (String[] args)
  {
    System.out.println("Hola mundo.");
  }
}
