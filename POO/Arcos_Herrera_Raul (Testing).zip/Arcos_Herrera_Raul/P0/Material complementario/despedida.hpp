/*
 * Chao
 */
#ifndef DESPEDIDA_HPP_
#define DESPEDIDA_HPP_

void despedida();

#endif
