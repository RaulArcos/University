/*
 * OLA K ASE?
 */

#include <iostream>

void bienvenida()
{
  std::cout << "¡Hola!" << std::endl;
}
