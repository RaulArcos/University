#include "despedida.hpp"
#include <iostream>

void despedida()
{
  std::cout << "¡Adiós!" << std::endl;
}
