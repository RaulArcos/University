/*
 * Bienvenida
 */
#ifndef BIENVENIDA_HPP_
#define BIENVENIDA_HPP_

extern void bienvenida(void);

#endif
